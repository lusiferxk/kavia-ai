import React from 'react'
import FeatureItem from './FeatureItem'
export interface Feature {
  number: number
  title: string
  description: string
  image?: string
}
interface FeatureListProps {
  features: Feature[]
}
const FeatureList: React.FC<FeatureListProps> = ({ features }) => {
  return (
    <div className="max-w-4xl w-full space-y-0">
      {features.map((feature, index) => (
        <FeatureItem
          key={feature.number}
          number={feature.number}
          title={feature.title}
          description={feature.description}
          image={feature.image}
          isLast={index === features.length - 1}
        />
      ))}
    </div>
  )
}
export default FeatureList
