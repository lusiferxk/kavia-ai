'use client'

import DocumentationGradientBackground from "../../GradientBackground"

export default function HeroSection() {
    return (
        <section className="w-full px-24 py-20 flex justify-center items-center">
            <div className="w-full mx-auto rounded-3xl bg-black/60 backdrop-blur-lg border border-[#2e2e2e] px-8 py-28 text-center">
                <h1 className="text-white text-4xl md:text-5xl font-medium mb-4">
                    Inspect. Plan. Build.
                </h1>
                <p className="text-gray-300 mb-8">
                    Transform Enterprise Software Development Process with KAVIA AI
                </p>
                <button className="bg-[#f97316] hover:bg-[#fb923c] transition text-white text-sm px-6 py-3 rounded-xl shadow-md">
                    Get started with KAVIA AI
                </button>
                <DocumentationGradientBackground />
            </div>
        </section>
    )
}