import React from 'react'
interface FeatureItemProps {
  number: number
  title: string
  description: string
  image?: string
  isLast?: boolean
}
const FeatureItem = ({
  number,
  title,
  description,
  image,
  isLast = false,
}: FeatureItemProps) => {
  return (
    <div className="relative">
      <div className="flex gap-6">
        <div className="flex-shrink-0 relative">
          {!isLast && (
            <div className="absolute top-5 left-1/2 transform -translate-x-1/2 w-0.5 h-full bg-[#4f4c4d] z-0"></div>
          )}
          <div className="flex items-center justify-center w-7 h-7 rounded-full bg-[#4f4c4d] text-white border border-gray-700 relative z-10">
            {number}
          </div>
        </div>
        <div className="flex flex-col gap-2 pb-8">
          <h3 className="text-white font-medium">{title}</h3>
          <p className="text-gray-300">{description}</p>
          {image && (
            <div className="relative p-1 rounded-xl overflow-hidden border">
              <img
                src={image}
                alt={`Illustration for ${title}`}
                className="w-full h-auto object-cover rounded-xl"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
export default FeatureItem
